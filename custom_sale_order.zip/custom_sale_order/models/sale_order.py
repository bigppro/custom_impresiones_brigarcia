# -*- coding: utf-8 -*-

from odoo import models, fields, api

class custom_sale_order(models.Model):
    #_name = 'custom_sale_order.custom_sale_order'
    _inherit = "sale.order"
    #_rec_name ="partner_id"

    project = fields.Many2one('project.project', string="Proyecto", help="Elija el proyecto asignado para este presupuesto")
    detail = fields.Char(string='Detalle', help="Establecer un detalle breve del proyecto")

    """ @api.multi
    def _get_default_wpartner(self):
        return self.env['res.partner'].search([('parent_id.id', '=', self.partner_id.id)]) """

    contact = fields.Many2one('res.partner', string="Contacto", help="Elija el contacto asignado en la empresa", store=True)

    """ project_comments = fields.Text(String="Condiciones",help="Indique las condiciones del proyecto/presupuesto")
    general_conditions = fields.Text(String="Generales",help="Indique las condiciones del proyecto/presupuesto")
     """