from odoo import api, models
# from bahttext import bahttext
# ต้อง install bahttext lib ก่อน
# pip/pip3 install bahttext

class CustomReport(models.Model):
    _inherit = 'sale.order'

