# odoo12
# This app to hide message that show in order_lines when select a product which quantity is less than quantity on hand
